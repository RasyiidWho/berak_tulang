import { localStorageStore } from '@skeletonlabs/skeleton';


export const storeBerak = localStorageStore('arrayBerak', []);

export const AlasanBerak = localStorageStore('AlasanBerak', []);