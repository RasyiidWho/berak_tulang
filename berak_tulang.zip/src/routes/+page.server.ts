import type { PageServerLoad } from './$types';

export const load = (async ({ cookies }) => {
	return {};
}) satisfies PageServerLoad;
	