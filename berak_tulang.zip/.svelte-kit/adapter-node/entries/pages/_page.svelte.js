import { n as split_css_unit, c as create_ssr_component, a as compute_rest_props, l as subscribe, o as createEventDispatcher, g as escape, h as add_attribute, f as each, v as validate_component } from "../../chunks/ssr.js";
import { p as prefersReducedMotionStore, l as localStorageStore, b as berak } from "../../chunks/ProgressBar.svelte_svelte_type_style_lang.js";
function cubicOut(t) {
  const f = t - 1;
  return f * f * f + 1;
}
function fly(node, { delay = 0, duration = 400, easing = cubicOut, x = 0, y = 0, opacity = 0 } = {}) {
  const style = getComputedStyle(node);
  const target_opacity = +style.opacity;
  const transform = style.transform === "none" ? "" : style.transform;
  const od = target_opacity * (1 - opacity);
  const [xValue, xUnit] = split_css_unit(x);
  const [yValue, yUnit] = split_css_unit(y);
  return {
    delay,
    duration,
    easing,
    css: (t, u) => `
			transform: ${transform} translate(${(1 - t) * xValue}${xUnit}, ${(1 - t) * yValue}${yUnit});
			opacity: ${target_opacity - od * u}`
  };
}
function scale(node, { delay = 0, duration = 400, easing = cubicOut, start = 0, opacity = 0 } = {}) {
  const style = getComputedStyle(node);
  const target_opacity = +style.opacity;
  const transform = style.transform === "none" ? "" : style.transform;
  const sd = 1 - start;
  const od = target_opacity * (1 - opacity);
  return {
    delay,
    duration,
    easing,
    css: (_t, u) => `
			transform: ${transform} scale(${1 - sd * u});
			opacity: ${target_opacity - od * u}
		`
  };
}
const cBase = "textarea cursor-pointer";
const cChipWrapper = "space-y-4";
const cChipList = "flex flex-wrap gap-2";
const cInputField = "unstyled bg-transparent border-0 !ring-0 p-0 w-full";
const InputChip = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let classesInvalid;
  let classesBase;
  let classesChipWrapper;
  let classesChipList;
  let classesInput;
  let $$restProps = compute_rest_props($$props, [
    "input",
    "name",
    "value",
    "whitelist",
    "max",
    "minlength",
    "maxlength",
    "allowUpperCase",
    "allowDuplicates",
    "validation",
    "duration",
    "required",
    "chips",
    "invalid",
    "padding",
    "rounded",
    "regionChipWrapper",
    "regionChipList",
    "regionInput",
    "transitions",
    "listTransitionIn",
    "listTransitionInParams",
    "listTransitionOut",
    "listTransitionOutParams",
    "chipTransitionIn",
    "chipTransitionInParams",
    "chipTransitionOut",
    "chipTransitionOutParams"
  ]);
  let $prefersReducedMotionStore, $$unsubscribe_prefersReducedMotionStore;
  $$unsubscribe_prefersReducedMotionStore = subscribe(prefersReducedMotionStore, (value2) => $prefersReducedMotionStore = value2);
  createEventDispatcher();
  let { input = "" } = $$props;
  let { name } = $$props;
  let { value = [] } = $$props;
  let { whitelist = [] } = $$props;
  let { max = -1 } = $$props;
  let { minlength = -1 } = $$props;
  let { maxlength = -1 } = $$props;
  let { allowUpperCase = false } = $$props;
  let { allowDuplicates = false } = $$props;
  let { validation = () => true } = $$props;
  let { duration = 150 } = $$props;
  let { required = false } = $$props;
  let { chips = "variant-filled" } = $$props;
  let { invalid = "input-error" } = $$props;
  let { padding = "p-2" } = $$props;
  let { rounded = "rounded-container-token" } = $$props;
  let { regionChipWrapper = "" } = $$props;
  let { regionChipList = "" } = $$props;
  let { regionInput = "" } = $$props;
  let { transitions = !$prefersReducedMotionStore } = $$props;
  let { listTransitionIn = fly } = $$props;
  let { listTransitionInParams = { duration: 150, opacity: 0, y: -20 } } = $$props;
  let { listTransitionOut = fly } = $$props;
  let { listTransitionOutParams = { duration: 150, opacity: 0, y: -20 } } = $$props;
  let { chipTransitionIn = scale } = $$props;
  let { chipTransitionInParams = { duration: 150, opacity: 0 } } = $$props;
  let { chipTransitionOut = scale } = $$props;
  let { chipTransitionOutParams = { duration: 150, opacity: 0 } } = $$props;
  let chipValues = value?.map((val) => {
    return { val, id: Math.random() };
  }) || [];
  let selectElement;
  if ($$props.input === void 0 && $$bindings.input && input !== void 0)
    $$bindings.input(input);
  if ($$props.name === void 0 && $$bindings.name && name !== void 0)
    $$bindings.name(name);
  if ($$props.value === void 0 && $$bindings.value && value !== void 0)
    $$bindings.value(value);
  if ($$props.whitelist === void 0 && $$bindings.whitelist && whitelist !== void 0)
    $$bindings.whitelist(whitelist);
  if ($$props.max === void 0 && $$bindings.max && max !== void 0)
    $$bindings.max(max);
  if ($$props.minlength === void 0 && $$bindings.minlength && minlength !== void 0)
    $$bindings.minlength(minlength);
  if ($$props.maxlength === void 0 && $$bindings.maxlength && maxlength !== void 0)
    $$bindings.maxlength(maxlength);
  if ($$props.allowUpperCase === void 0 && $$bindings.allowUpperCase && allowUpperCase !== void 0)
    $$bindings.allowUpperCase(allowUpperCase);
  if ($$props.allowDuplicates === void 0 && $$bindings.allowDuplicates && allowDuplicates !== void 0)
    $$bindings.allowDuplicates(allowDuplicates);
  if ($$props.validation === void 0 && $$bindings.validation && validation !== void 0)
    $$bindings.validation(validation);
  if ($$props.duration === void 0 && $$bindings.duration && duration !== void 0)
    $$bindings.duration(duration);
  if ($$props.required === void 0 && $$bindings.required && required !== void 0)
    $$bindings.required(required);
  if ($$props.chips === void 0 && $$bindings.chips && chips !== void 0)
    $$bindings.chips(chips);
  if ($$props.invalid === void 0 && $$bindings.invalid && invalid !== void 0)
    $$bindings.invalid(invalid);
  if ($$props.padding === void 0 && $$bindings.padding && padding !== void 0)
    $$bindings.padding(padding);
  if ($$props.rounded === void 0 && $$bindings.rounded && rounded !== void 0)
    $$bindings.rounded(rounded);
  if ($$props.regionChipWrapper === void 0 && $$bindings.regionChipWrapper && regionChipWrapper !== void 0)
    $$bindings.regionChipWrapper(regionChipWrapper);
  if ($$props.regionChipList === void 0 && $$bindings.regionChipList && regionChipList !== void 0)
    $$bindings.regionChipList(regionChipList);
  if ($$props.regionInput === void 0 && $$bindings.regionInput && regionInput !== void 0)
    $$bindings.regionInput(regionInput);
  if ($$props.transitions === void 0 && $$bindings.transitions && transitions !== void 0)
    $$bindings.transitions(transitions);
  if ($$props.listTransitionIn === void 0 && $$bindings.listTransitionIn && listTransitionIn !== void 0)
    $$bindings.listTransitionIn(listTransitionIn);
  if ($$props.listTransitionInParams === void 0 && $$bindings.listTransitionInParams && listTransitionInParams !== void 0)
    $$bindings.listTransitionInParams(listTransitionInParams);
  if ($$props.listTransitionOut === void 0 && $$bindings.listTransitionOut && listTransitionOut !== void 0)
    $$bindings.listTransitionOut(listTransitionOut);
  if ($$props.listTransitionOutParams === void 0 && $$bindings.listTransitionOutParams && listTransitionOutParams !== void 0)
    $$bindings.listTransitionOutParams(listTransitionOutParams);
  if ($$props.chipTransitionIn === void 0 && $$bindings.chipTransitionIn && chipTransitionIn !== void 0)
    $$bindings.chipTransitionIn(chipTransitionIn);
  if ($$props.chipTransitionInParams === void 0 && $$bindings.chipTransitionInParams && chipTransitionInParams !== void 0)
    $$bindings.chipTransitionInParams(chipTransitionInParams);
  if ($$props.chipTransitionOut === void 0 && $$bindings.chipTransitionOut && chipTransitionOut !== void 0)
    $$bindings.chipTransitionOut(chipTransitionOut);
  if ($$props.chipTransitionOutParams === void 0 && $$bindings.chipTransitionOutParams && chipTransitionOutParams !== void 0)
    $$bindings.chipTransitionOutParams(chipTransitionOutParams);
  classesInvalid = "";
  classesBase = `${cBase} ${padding} ${rounded} ${$$props.class ?? ""} ${classesInvalid}`;
  classesChipWrapper = `${cChipWrapper} ${regionChipWrapper}`;
  classesChipList = `${cChipList} ${regionChipList}`;
  classesInput = `${cInputField} ${regionInput}`;
  chipValues = value?.map((val, i) => {
    if (chipValues[i]?.val === val)
      return chipValues[i];
    return { id: Math.random(), val };
  }) || [];
  $$unsubscribe_prefersReducedMotionStore();
  return `<div class="${[
    "input-chip " + escape(classesBase, true),
    $$restProps.disabled ? "opacity-50" : ""
  ].join(" ").trim()}"> <div class="h-0 overflow-hidden"><select${add_attribute("name", name, 0)} multiple ${required ? "required" : ""} tabindex="-1"${add_attribute("this", selectElement, 0)}>${each(value, (option) => {
    return `<option${add_attribute("value", option, 0)}>${escape(option)}</option>`;
  })}</select></div>  <div class="${"input-chip-wrapper " + escape(classesChipWrapper, true)}"> <form><input type="text"${add_attribute("placeholder", $$restProps.placeholder ?? "Enter values...", 0)} class="${"input-chip-field " + escape(classesInput, true)}" ${$$restProps.disabled ? "disabled" : ""}${add_attribute("value", input, 0)}></form>  ${chipValues.length ? `<div class="${"input-chip-list " + escape(classesChipList, true)}">${each(chipValues, ({ id, val }, i) => {
    return `<div><button type="button" class="${"chip " + escape(chips, true)}"><span>${escape(val)}</span> <span data-svelte-h="svelte-1p578dz">✕</span></button> </div>`;
  })}</div>` : ``}</div></div>`;
});
localStorageStore("arrayBerak", []);
const AlasanBerak = localStorageStore("AlasanBerak", []);
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: ".svelte-1m9n4ab{-webkit-touch-callout:none;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  let storeAlasanBerak = [];
  AlasanBerak.subscribe((v) => {
    storeAlasanBerak = v;
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  $$result.css.add(css);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = `  <div class="container svelte-1m9n4ab"><div class="flex w-screen svelte-1m9n4ab"><div class="m-auto grid grid-cols-1 gap-10 text-center pt-10 svelte-1m9n4ab"><b class="btn !bg-transparent svelte-1m9n4ab" data-svelte-h="svelte-kj6gn7"><img${add_attribute("src", berak, 0)} alt="logo" class="svelte-1m9n4ab"></b> <h1 class="h1 svelte-1m9n4ab" data-svelte-h="svelte-f5s8lg">Mari Berak Bersama Kami!</h1> <div class="m-5 svelte-1m9n4ab">   ${validate_component(InputChip, "InputChip").$$render(
      $$result,
      {
        name: "chips",
        placeholder: "Kenapa kamu ingin sekali berak?",
        value: storeAlasanBerak
      },
      {
        value: ($$value) => {
          storeAlasanBerak = $$value;
          $$settled = false;
        }
      },
      {}
    )} </div></div></div> </div>`;
  } while (!$$settled);
  return $$rendered;
});
export {
  Page as default
};
