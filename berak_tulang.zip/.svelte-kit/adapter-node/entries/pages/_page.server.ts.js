const load = async ({ cookies }) => {
  return {};
};
export {
  load
};
