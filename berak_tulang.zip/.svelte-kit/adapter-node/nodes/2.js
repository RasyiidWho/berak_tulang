import * as server from '../entries/pages/_page.server.ts.js';

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/+page.server.ts";
export const imports = ["_app/immutable/nodes/2.49b722d6.js","_app/immutable/chunks/scheduler.440da154.js","_app/immutable/chunks/index.b5d7341b.js","_app/immutable/chunks/ProgressBar.svelte_svelte_type_style_lang.1809d16d.js","_app/immutable/chunks/index.f810e111.js"];
export const stylesheets = ["_app/immutable/assets/2.ea1611ef.css","_app/immutable/assets/ProgressBar.4f1e9ba5.css"];
export const fonts = [];
