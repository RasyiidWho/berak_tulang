

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.ec3c1eee.js","_app/immutable/chunks/scheduler.440da154.js","_app/immutable/chunks/index.b5d7341b.js","_app/immutable/chunks/singletons.e613cb35.js","_app/immutable/chunks/index.f810e111.js"];
export const stylesheets = [];
export const fonts = [];
