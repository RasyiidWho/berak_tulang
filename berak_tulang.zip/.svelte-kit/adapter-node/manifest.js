export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {"start":"_app/immutable/entry/start.58351683.js","app":"_app/immutable/entry/app.9cd49c8e.js","imports":["_app/immutable/entry/start.58351683.js","_app/immutable/chunks/scheduler.440da154.js","_app/immutable/chunks/singletons.e613cb35.js","_app/immutable/chunks/index.f810e111.js","_app/immutable/entry/app.9cd49c8e.js","_app/immutable/chunks/scheduler.440da154.js","_app/immutable/chunks/index.b5d7341b.js"],"stylesheets":[],"fonts":[]},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
}
})();

export const prerendered = new Set([]);
